import math

x = int(input())
y = int(input())

def add(x,y):
    sm=x+y





print("выполнение программы-1, конец-0")
t=int(input())
while t !=0:
    print("Выберите действие: сложение-1, вычитание-2, умножение-3, деление-4.")
    i=int(input())
    if i == 1:
        print("введите числа а, b.")

        add()
        print(add)



#
# if
#
# def mins ():
#
# def dell ():
#
# def prod ():
#
#
#
#
#
#
# z=0
# z=0
# while z != '0':
#     print('введите данные для вычислений')
#     a = int(input())
#     z = input()
#     y = int(input())
#
#     if z == '*':
#         f= a*y
#         print(f)
#     elif z == '+':
#         f= a+y
#         print(f)
#     elif z == '-':
#         f= a-y
#         print(f)
#     elif z == '/':
#         f= a/y
#
# else:
#     print('введен  0.')