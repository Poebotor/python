import math

print("укажите значение альфа"), print("укажите значение бета")
alfa=int(input())
beta=int(input())

z1=(math.cos(alfa)**4)+(math.sin(beta)**2)+(1/4*(math.sin(alfa*2))**2)-1
print(z1)