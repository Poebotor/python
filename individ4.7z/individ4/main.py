import math
z=0
z=0
while z != '0':
    print('введите данные для вычислений')
    a = int(input())
    z = input()
    y = int(input())

    if z == '*':
        f= a*y
        print(f)
    elif z == '+':
        f= a+y
        print(f)
    elif z == '-':
        f= a-y
        print(f)
    elif z == '/':
        f= a/y

else:
    print('введен  0.')