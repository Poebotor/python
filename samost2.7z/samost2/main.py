import math

print('Введите чему равен x, y, z:')

x = int(input('x = '))
y = int(input('y = '))
z = int(input('z = '))
f = (5 * (math.acosh(x)-1/4 * math.acosh(x))*(x + 3*[x-y] + x**2)/[x-y]*z+x**2)
print('f = ', f)
