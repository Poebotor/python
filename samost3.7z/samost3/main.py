import math

print('введите чему равны  x, y, z:')
x = float(input('x = '))
y = float(input('y = '))
z = float(input('z = '))
if (x == 0) and (y == 0) and (z == 0) and ValueError:
    print("числа не должны быть равны нулю")
else:
    try:
        f = (5 * (math.acosh(x)-1/4 * math.acosh(x))*(x + 3*abs(x-y) + x**2)/abs(x-y)*z+x**2)
        print('f = ', f)
    except ValueError:
        print('неверное значение переменной, введите число')

