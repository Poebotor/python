
spisok = [1,2,7,0,"baby",43,"big"]
print (spisok)
spisok.reverse()
print(spisok)

def change ():
    k = -1
    for i in range(1):
        print("было - ", i, spisok)
        spisok[k], spisok[i] = spisok[i], spisok[k]
        print("стало    ", spisok)
        k -= 1

change()


