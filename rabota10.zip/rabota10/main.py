import telebot
# Создаем экземпляр бота
bot = telebot.TeleBot('6064241028:AAGBegEEkVOByINqDqoLdxeWCvjURP7KDwI')

books=["1984", "Убить пересмешника","Мастер и Маргарита", "Война и мир" ,"Атлант расправил плечи", "Три товарища" ,"Маленький принц" , "Гарри Поттер и философский камень",
"Анна Каренина" , "Тень горы" ,"Метро 2033" ,"Портрет Дориана Грея", "Великий Гэтсби",
"Мартин Иден" , "Американский психопат", "Маленькие женщины" , "Повелитель мух" , "Сто лет одиночества" , "Война миров", "Крестный отец" ,
"Девушка с татуировкой дракона" , "О дивный новый мир"  , "Сумерки" , "Пикник на обочине", "Дневник Анны Франк" , "Маленький зеленый человечек" ,
"Граф Монте-Кристо"]

booksreturn=[] for item in books:
    booksreturn.append(item)
# Строка для записи рандомной книги
str=''
#Строка для записи книг от пользователя
item=''

# Функция, обрабатывающая команду /start
@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Нажмите 1 чтобы зарандомить:\nНажмите 2 чтобы добавить элемент:\nНажмите 3 ' 'чтобы удалить элемент:')

# Получение сообщений от юзера
@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == '1':
        bot.send_message(message.chat.id, 'Я зарандомил: ' + RandomElement())
        if message.text == '2': bot.send_message(message.chat.id, 'Напишите книгу ')
        bot.register_next_step_handler(message,AddElement)
        if message.text == '3': bot.send_message(message.chat.id, 'Напишите книгу, который надо удалить')
        bot.register_next_step_handler(message, RemoveElement)
# Метод для рандомной книги
def RandomElement():
    if len(booksreturn)!=0:
        index = random.randint(0, len(booksreturn) - 1)
        str = booksreturn[index]
        booksreturn.remove (booksreturn[index])
    else:
        for item in books:
            booksreturn.append(item)
            index = random.randint(0, len(booksreturn) - 1)
            str = booksreturn[index]
            booksreturn.remove(booksreturn[index])
            return str
# Метод для добавление книги с проверкой на существующие книги
def AddElement(message):
    global item 
    item=message.text
    if not books.__contains__(item):
        books.append(item)
        booksreturn.append(item)
        bot.send_message(message.from_user.id, f'Добавил книгу {message.text}');
    else:
        bot.send_message(message.chat.id, f'книга {message.text} существует, напишите новый')
        bot.register_next_step_handler(message,AddElement)
# Метод для удаления цвета с проверкой на существующие книги
def RemoveElement(message):
    global item
    item = message.text
    if books.__contains__(item):
        books.remove(item)
        booksreturn.remove(item)
        bot.send_message(message.from_user.id, f'Удалил книгу {message.text}');
    else:
        bot.send_message(message.from_user.id, f'книги не существует в списке, хотите добавлю?(Скажите да)');
        bot.register_next_step_handler(message, AddElement)
    # Запускаем бота
    bot.polling(none_stop=True, interval=0)